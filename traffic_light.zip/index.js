$(document).ready(function () {




    $('#red-light').click(function (){
      $(this).css({"opacity": "0.3"});
    });
    $('#yellow-light').click(function (){
      $(this).css({"opacity": "0.3"});
    });
    $('#green-light').click(function (){
      $(this).css({"opacity": "0.3"});
    });

    setTimeout(youHaveToBeReady, 3000);

    function youHaveToBeReady () {
      $('#red-light').css({"opacity": "0.3"});
      $('#yellow-light').css({"opacity": "1"});
      setTimeout(youHaveToGo, 2000);
    }

    function youHaveToGo () {
      $('#yellow-light').css({"opacity": "0.3"});
      $('#green-light').css({"opacity": "1"});
      setTimeout(youHaveToStop, 3000);
    }

    function youHaveToStop () {
      $('#green-light').css({"opacity": "0.3"});
      $('#red-light').css({"opacity": "1"});
      setTimeout(youHaveToBeReady, 3000);
    }

    // $('#red-light').dblclick(function (){
    //   $(this).css({"opacity": "1"});
    // });
    // $('#yellow-light').dblclick(function (){
    //   $(this).css({"opacity": "1"});
    // });
    // $('#green-light').dblclick(function (){
    //   $(this).css({"opacity": "1"});
    // });

    // $('#red-light').css({"opacity": "1"});
    // $('#yellow-light').css({"opacity": "1"});
    // $('#green-light').css({"opacity": "1"});

});
